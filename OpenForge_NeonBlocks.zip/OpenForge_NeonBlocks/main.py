import os
import json
import random
import math

from kivy.app import App
from kivy.clock import Clock
from kivy.animation import Animation
from kivy.metrics import dp
from kivy.graphics import (
    Color, Rectangle, RoundedRectangle, Ellipse, Line
)
from kivy.uix.widget import Widget
from kivy.uix.boxlayout import BoxLayout
from kivy.uix.floatlayout import FloatLayout
from kivy.uix.button import Button
from kivy.uix.label import Label
from kivy.uix.screenmanager import ScreenManager, Screen
from kivy.uix.popup import Popup


# =====================================================
# CONFIGURATION
# =====================================================

GRID = 10

BG = (0.025, 0.025, 0.075, 1)
PANEL = (0.07, 0.06, 0.14, 1)

CYAN = (0.0, 0.85, 1, 1)
PURPLE = (0.65, 0.3, 1, 1)
PINK = (1, 0.2, 0.65, 1)
GREEN = (0.15, 1, 0.55, 1)
WHITE = (0.92, 0.95, 1, 1)

COLORS = [CYAN, PURPLE, PINK, GREEN]

SHAPES = [
    [(0, 0)],
    [(0, 0), (1, 0)],
    [(0, 0), (0, 1)],
    [(0, 0), (1, 0), (2, 0)],
    [(0, 0), (0, 1), (0, 2)],
    [(0, 0), (1, 0), (0, 1), (1, 1)],
    [(0, 0), (1, 0), (2, 0), (1, 1)],
    [(0, 0), (0, 1), (0, 2), (1, 2)],
    [(0, 0), (1, 0), (2, 0), (2, 1)],
    [(0, 0), (1, 0), (2, 0),
     (0, 1), (1, 1), (2, 1)],
    [(0, 0), (0, 1), (1, 1), (1, 2)]
]


# =====================================================
# SAVE DATA
# =====================================================

def data_path():
    return os.path.join(
        App.get_running_app().user_data_dir,
        "neon_blocks_v5.json"
    )


def load_data():
    defaults = {
        "best": 0,
        "games": 0,
        "rows": 0,
        "cols": 0,
        "blocks": 0,
        "animations": True,
        "effects": True
    }

    try:
        with open(data_path(), "r") as f:
            saved = json.load(f)

        if isinstance(saved, dict):
            defaults.update(saved)

    except Exception:
        pass

    return defaults


def save_data(data):
    try:
        with open(data_path(), "w") as f:
            json.dump(data, f)
    except Exception:
        pass


# =====================================================
# SHAPES
# =====================================================

def rotate_shape(shape):
    rotated = [(y, -x) for x, y in shape]

    min_x = min(x for x, y in rotated)
    min_y = min(y for x, y in rotated)

    return sorted(
        (x - min_x, y - min_y)
        for x, y in rotated
    )


def shape_size(shape):
    return (
        max(x for x, y in shape) + 1,
        max(y for x, y in shape) + 1
    )


# =====================================================
# UI HELPERS
# =====================================================

def make_button(text, color=CYAN, height=dp(48)):
    return Button(
        text=text,
        size_hint_y=None,
        height=height,
        background_normal="",
        background_down="",
        background_color=(0.09, 0.08, 0.2, 1),
        color=color,
        font_size="15sp"
    )


def make_label(text, size=16, color=WHITE):
    return Label(
        text=text,
        font_size=f"{size}sp",
        color=color,
        halign="center",
        valign="middle"
    )


# =====================================================
# DIGITAL SPACE BACKGROUND
# =====================================================

class SpaceBackground(Widget):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.particles = []

        for _ in range(38):
            self.particles.append({
                "x": random.random(),
                "y": random.random(),
                "speed": random.uniform(0.012, 0.045),
                "size": random.uniform(1.0, 2.3),
                "phase": random.uniform(0, 6.28)
            })

        self.pulse = 0
        self.effects_enabled = True

        self.bind(
            pos=self.draw,
            size=self.draw
        )

        Clock.schedule_interval(
            self.update_particles, 1 / 30
        )

    def update_particles(self, dt):
        for p in self.particles:
            p["y"] += p["speed"] * dt
            p["phase"] += dt * 2

            if p["y"] > 1:
                p["y"] = 0
                p["x"] = random.random()

        self.draw()

    def trigger_pulse(self, strength=1):
        if not self.effects_enabled:
            return

        self.pulse = strength

        Animation.cancel_all(self, "pulse")

        anim = Animation(
            pulse=0,
            duration=0.65
        )
        anim.start(self)

    def draw(self, *args):
        self.canvas.clear()

        with self.canvas:
            Color(0.025, 0.012, 0.075, 1)
            Rectangle(
                pos=self.pos,
                size=self.size
            )

            # Purple atmosphere
            Color(0.22, 0.035, 0.38, 0.09 + self.pulse * 0.12)
            Ellipse(
                pos=(
                    self.x + self.width * 0.05,
                    self.y + self.height * 0.30
                ),
                size=(
                    self.width * 0.95,
                    self.height * 0.55
                )
            )

            # Blue atmosphere
            Color(0.0, 0.25, 0.55, 0.05 + self.pulse * 0.08)
            Ellipse(
                pos=(
                    self.x + self.width * 0.30,
                    self.y + self.height * 0.05
                ),
                size=(
                    self.width * 0.85,
                    self.height * 0.40
                )
            )

            for p in self.particles:
                brightness = (
                    0.25 + 0.35 *
                    math.sin(p["phase"])
                )

                Color(
                    0.25,
                    0.75,
                    1.0,
                    brightness
                )

                px = self.x + p["x"] * self.width
                py = self.y + p["y"] * self.height
                s = dp(p["size"])

                Ellipse(
                    pos=(px, py),
                    size=(s, s)
                )


# =====================================================
# NEON EFFECTS LAYER
# =====================================================

class EffectsLayer(Widget):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.particles = []
        self.wave_progress = -1
        self.wave_color = CYAN
        self.active = True

        Clock.schedule_interval(
            self.update_effects, 1 / 30
        )

    def burst(self, x, y, color, amount=22):
        if not self.active:
            return

        for _ in range(amount):
            angle = random.uniform(0, math.pi * 2)
            speed = random.uniform(35, 115)

            self.particles.append({
                "x": x,
                "y": y,
                "vx": math.cos(angle) * speed,
                "vy": math.sin(angle) * speed,
                "life": random.uniform(0.35, 0.8),
                "max_life": 0.8,
                "size": random.uniform(2, 4),
                "color": color
            })

    def start_wave(self, color=CYAN):
        if not self.active:
            return

        self.wave_progress = 0
        self.wave_color = color

    def update_effects(self, dt):
        for p in self.particles:
            p["x"] += p["vx"] * dt
            p["y"] += p["vy"] * dt

            p["life"] -= dt

            p["vx"] *= 0.96
            p["vy"] *= 0.96

        self.particles = [
            p for p in self.particles
            if p["life"] > 0
        ]

        if self.wave_progress >= 0:
            self.wave_progress += dt * 2.2

            if self.wave_progress >= 1:
                self.wave_progress = -1

        self.draw()

    def draw(self, *args):
        self.canvas.clear()

        if not self.active:
            return

        with self.canvas:
            for p in self.particles:
                alpha = max(
                    0,
                    p["life"] / p["max_life"]
                )

                Color(
                    p["color"][0],
                    p["color"][1],
                    p["color"][2],
                    alpha
                )

                s = dp(p["size"])

                Ellipse(
                    pos=(
                        p["x"] - s / 2,
                        p["y"] - s / 2
                    ),
                    size=(s, s)
                )

            if self.wave_progress >= 0:
                Color(
                    self.wave_color[0],
                    self.wave_color[1],
                    self.wave_color[2],
                    0.55
                )

                y = (
                    self.y +
                    self.height * self.wave_progress
                )

                Line(
                    points=[
                        self.x, y,
                        self.right, y
                    ],
                    width=dp(2)
                )


# =====================================================
# BOARD
# =====================================================

class GameBoard(Widget):

    def __init__(self, game, **kwargs):
        super().__init__(**kwargs)

        self.game = game

        self.cells = [
            [None for _ in range(GRID)]
            for _ in range(GRID)
        ]

        self.cell_size = 0
        self.board_left = 0
        self.board_bottom = 0

        self.bind(
            pos=self.draw_board,
            size=self.draw_board
        )

    def draw_board(self, *args):
        self.canvas.clear()

        with self.canvas:
            Color(*BG)
            Rectangle(
                pos=self.pos,
                size=self.size
            )

            self.cell_size = min(
                self.width / GRID,
                self.height / GRID
            )

            board_w = self.cell_size * GRID
            board_h = self.cell_size * GRID

            self.board_left = (
                self.center_x - board_w / 2
            )

            self.board_bottom = (
                self.center_y - board_h / 2
            )

            for row in range(GRID):
                for col in range(GRID):
                    x = (
                        self.board_left +
                        col * self.cell_size
                    )

                    y = (
                        self.board_bottom +
                        row * self.cell_size
                    )

                    Color(0.13, 0.12, 0.23, 1)

                    RoundedRectangle(
                        pos=(x + 1, y + 1),
                        size=(
                            self.cell_size - 2,
                            self.cell_size - 2
                        ),
                        radius=[dp(4)]
                    )

                    color = self.cells[row][col]

                    if color is not None:
                        Color(*color)

                        RoundedRectangle(
                            pos=(x + 3, y + 3),
                            size=(
                                self.cell_size - 6,
                                self.cell_size - 6
                            ),
                            radius=[dp(5)]
                        )

    def target_origin(self, shape, touch_x, touch_y):
        if self.cell_size <= 0:
            return None

        width, height = shape_size(shape)

        center_x = (
            touch_x - self.board_left
        ) / self.cell_size

        center_y = (
            touch_y - self.board_bottom
        ) / self.cell_size

        col = int(round(center_x - width / 2))
        row = int(round(center_y - height / 2))

        return row, col

    def can_place(self, shape, row, col):
        for dx, dy in shape:
            r = row + dy
            c = col + dx

            if not (
                0 <= r < GRID and
                0 <= c < GRID
            ):
                return False

            if self.cells[r][c] is not None:
                return False

        return True

    def place(self, shape, row, col, color):
        if not self.can_place(shape, row, col):
            return False

        for dx, dy in shape:
            self.cells[row + dy][col + dx] = color

        self.draw_board()
        return True

    def clear_lines(self):
        full_rows = [
            r for r in range(GRID)
            if all(
                self.cells[r][c] is not None
                for c in range(GRID)
            )
        ]

        full_cols = [
            c for c in range(GRID)
            if all(
                self.cells[r][c] is not None
                for r in range(GRID)
            )
        ]

        for r in full_rows:
            for c in range(GRID):
                self.cells[r][c] = None

        for c in full_cols:
            for r in range(GRID):
                self.cells[r][c] = None

        self.draw_board()

        return full_rows, full_cols

    def reset(self):
        self.cells = [
            [None for _ in range(GRID)]
            for _ in range(GRID)
        ]

        self.draw_board()


# =====================================================
# DRAG PREVIEW
# =====================================================

class DragPreview(Widget):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.board = None
        self.shape = []
        self.row = 0
        self.col = 0
        self.color = CYAN
        self.valid = False
        self.visible = False

    def show(self, board, shape, color, touch):
        self.board = board
        self.shape = shape
        self.color = color
        self.visible = True

        self.update_position(touch)

    def update_position(self, touch):
        if not self.visible or not self.board:
            return

        origin = self.board.target_origin(
            self.shape,
            touch.x,
            touch.y
        )

        if origin is None:
            return

        self.row, self.col = origin

        self.valid = self.board.can_place(
            self.shape,
            self.row,
            self.col
        )

        self.draw()

    def hide(self):
        self.visible = False
        self.canvas.clear()

    def draw(self):
        self.canvas.clear()

        if not self.visible or not self.board:
            return

        board = self.board
        cell = board.cell_size

        color = GREEN if self.valid else PINK

        with self.canvas:
            for dx, dy in self.shape:
                x = (
                    board.board_left +
                    (self.col + dx) * cell
                )

                y = (
                    board.board_bottom +
                    (self.row + dy) * cell
                )

                Color(
                    color[0],
                    color[1],
                    color[2],
                    0.55
                )

                RoundedRectangle(
                    pos=(x + 3, y + 3),
                    size=(cell - 6, cell - 6),
                    radius=[dp(5)]
                )


# =====================================================
# LINE EFFECT
# =====================================================

class LineFX(Widget):

    def __init__(self, **kwargs):
        super().__init__(**kwargs)

        self.opacity = 0

    def play(self, board, rows, cols, color):
        self.canvas.clear()

        cell = board.cell_size

        with self.canvas:
            for row in rows:
                y = (
                    board.board_bottom +
                    row * cell
                )

                Color(
                    color[0],
                    color[1],
                    color[2],
                    0.85
                )

                Rectangle(
                    pos=(board.board_left, y),
                    size=(cell * GRID, cell)
                )

            for col in cols:
                x = (
                    board.board_left +
                    col * cell
                )

                Color(
                    color[0],
                    color[1],
                    color[2],
                    0.85
                )

                Rectangle(
                    pos=(x, board.board_bottom),
                    size=(cell, cell * GRID)
                )

        self.opacity = 1

        Animation.cancel_all(self)

        anim = Animation(
            opacity=0,
            duration=0.55
        )

        anim.bind(
            on_complete=lambda *_: self.clear_fx()
        )

        anim.start(self)

    def clear_fx(self):
        self.canvas.clear()
        self.opacity = 0


# =====================================================
# PIECES
# =====================================================

class PieceWidget(Widget):

    def __init__(self, game, index, **kwargs):
        super().__init__(**kwargs)

        self.game = game
        self.index = index
        self.shape = []
        self.color = CYAN

        self.bind(
            pos=self.draw_piece,
            size=self.draw_piece
        )

    def set_piece(self, shape, color):
        self.shape = shape
        self.color = color
        self.draw_piece()

    def draw_piece(self, *args):
        self.canvas.clear()

        if not self.shape:
            return

        width, height = shape_size(self.shape)

        cell = min(
            dp(22),
            self.width / (width + 0.5),
            self.height / (height + 0.5)
        )

        total_w = width * cell
        total_h = height * cell

        start_x = self.center_x - total_w / 2
        start_y = self.center_y - total_h / 2

        with self.canvas:
            if (
                getattr(
                    self.game,
                    "selected_index",
                    -1
                ) == self.index
            ):
                Color(*CYAN)

                RoundedRectangle(
                    pos=(
                        self.x + 2,
                        self.y + 2
                    ),
                    size=(
                        self.width - 4,
                        self.height - 4
                    ),
                    radius=[dp(8)]
                )

            for dx, dy in self.shape:
                Color(*self.color)

                RoundedRectangle(
                    pos=(
                        start_x + dx * cell + 2,
                        start_y + dy * cell + 2
                    ),
                    size=(
                        cell - 4,
                        cell - 4
                    ),
                    radius=[dp(4)]
                )

    def on_touch_down(self, touch):
        if (
            self.collide_point(*touch.pos)
            and self.shape
        ):
            if self.game.game_over:
                return True

            self.game.start_drag(
                self.index,
                touch
            )

            touch.grab(self)
            return True

        return super().on_touch_down(touch)

    def on_touch_move(self, touch):
        if touch.grab_current is self:
            self.game.update_drag(touch)
            return True

        return super().on_touch_move(touch)

    def on_touch_up(self, touch):
        if touch.grab_current is self:
            touch.ungrab(self)

            self.game.finish_drag(
                self.index,
                touch
            )

            return True

        return super().on_touch_up(touch)


# =====================================================
# GAME SCREEN
# =====================================================

class GameScreen(Screen):

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)

        self.app = app

        self.score = 0
        self.best = app.data.get("best", 0)

        self.games_played = app.data.get("games", 0)
        self.total_rows = app.data.get("rows", 0)
        self.total_cols = app.data.get("cols", 0)
        self.total_blocks = app.data.get("blocks", 0)

        self.animations_enabled = app.data.get(
            "animations", True
        )

        self.effects_enabled = app.data.get(
            "effects", True
        )

        self.pieces = [None, None, None]

        self.selected_index = 0
        self.drag_index = None

        self.rotations_left = 3
        self.game_over = False
        self.game_recorded = False

        self.combo_streak = 0

        self.build_ui()
        self.new_game()

    # -------------------------------------------------
    # UI
    # -------------------------------------------------

    def build_ui(self):
        root = FloatLayout()

        self.background = SpaceBackground()
        root.add_widget(self.background)

        main = BoxLayout(
            orientation="vertical",
            padding=dp(10),
            spacing=dp(6)
        )

        root.add_widget(main)

        header = BoxLayout(
            size_hint_y=0.09,
            spacing=dp(5)
        )

        back = make_button(
            "‹ MENU",
            PURPLE,
            dp(42)
        )

        back.size_hint_x = 0.28

        back.bind(
            on_release=lambda *_: self.app.go_menu()
        )

        title = make_label(
            "[b]NEON BLOCKS[/b]",
            21,
            CYAN
        )

        title.markup = True

        header.add_widget(back)
        header.add_widget(title)

        main.add_widget(header)

        score_row = BoxLayout(
            size_hint_y=0.08
        )

        self.score_label = make_label(
            "SCORE  0",
            17,
            WHITE
        )

        self.best_label = make_label(
            f"BEST  {self.best}",
            15,
            PURPLE
        )

        score_row.add_widget(self.score_label)
        score_row.add_widget(self.best_label)

        main.add_widget(score_row)

        self.board = GameBoard(self)
        self.board.size_hint_y = 0.61

        main.add_widget(self.board)

        self.message = make_label(
            "DRAG A PIECE ONTO THE BOARD",
            12,
            CYAN
        )

        self.message.size_hint_y = 0.055

        main.add_widget(self.message)

        self.rotation_label = make_label(
            "ROTATIONS  3 / 3",
            13,
            GREEN
        )

        self.rotation_label.size_hint_y = 0.045

        main.add_widget(self.rotation_label)

        tray = BoxLayout(
            size_hint_y=0.13,
            spacing=dp(5)
        )

        self.piece_widgets = []

        for i in range(3):
            piece = PieceWidget(self, i)
            self.piece_widgets.append(piece)
            tray.add_widget(piece)

        main.add_widget(tray)

        controls = BoxLayout(
            size_hint_y=0.09,
            spacing=dp(7)
        )

        self.rotate_button = make_button(
            "ROTATE ↻",
            CYAN,
            dp(44)
        )

        self.rotate_button.bind(
            on_release=lambda *_: self.rotate_selected()
        )

        restart = make_button(
            "RESTART",
            PINK,
            dp(44)
        )

        restart.bind(
            on_release=lambda *_: self.confirm_restart()
        )

        controls.add_widget(self.rotate_button)
        controls.add_widget(restart)

        main.add_widget(controls)

        self.preview = DragPreview()
        root.add_widget(self.preview)

        self.line_fx = LineFX()
        root.add_widget(self.line_fx)

        self.effects = EffectsLayer()
        root.add_widget(self.effects)

        # Floating score animation
        self.score_pop = Label(
            text="",
            font_size="25sp",
            bold=True,
            color=CYAN,
            opacity=0,
            size_hint=(None, None),
            size=(dp(180), dp(45))
        )

        root.add_widget(self.score_pop)

        # Game over panel
        self.game_over_panel = BoxLayout(
            orientation="vertical",
            size_hint=(0.82, 0.34),
            pos_hint={
                "center_x": 0.5,
                "center_y": 0.5
            },
            opacity=0,
            disabled=True,
            padding=dp(12),
            spacing=dp(8)
        )

        with self.game_over_panel.canvas.before:
            Color(0.06, 0.04, 0.17, 0.98)

            self.panel_bg = RoundedRectangle(
                pos=self.game_over_panel.pos,
                size=self.game_over_panel.size,
                radius=[dp(14)]
            )

        self.game_over_panel.bind(
            pos=self.update_panel,
            size=self.update_panel
        )

        self.final_label = make_label(
            "[b]GAME OVER[/b]",
            24,
            PINK
        )

        self.final_label.markup = True

        self.final_score = make_label(
            "SCORE: 0",
            17,
            CYAN
        )

        again = make_button(
            "PLAY AGAIN",
            GREEN,
            dp(45)
        )

        again.bind(
            on_release=lambda *_: self.new_game()
        )

        self.game_over_panel.add_widget(self.final_label)
        self.game_over_panel.add_widget(self.final_score)
        self.game_over_panel.add_widget(again)

        root.add_widget(self.game_over_panel)

        self.add_widget(root)

    def update_panel(self, *args):
        self.panel_bg.pos = self.game_over_panel.pos
        self.panel_bg.size = self.game_over_panel.size

    # -------------------------------------------------
    # SAVE
    # -------------------------------------------------

    def save_stats(self):
        self.app.data.update({
            "best": self.best,
            "games": self.games_played,
            "rows": self.total_rows,
            "cols": self.total_cols,
            "blocks": self.total_blocks,
            "animations": self.animations_enabled,
            "effects": self.effects_enabled
        })

        save_data(self.app.data)

    # -------------------------------------------------
    # SCORE
    # -------------------------------------------------

    def update_score(self):
        self.score_label.text = (
            f"SCORE  {self.score}"
        )

        self.best_label.text = (
            f"BEST  {self.best}"
        )

    def add_score(self, amount):
        self.score += amount

        if self.score > self.best:
            self.best = self.score

        self.update_score()
        self.save_stats()

        if self.effects_enabled:
            self.show_score_pop(amount)

    def show_score_pop(self, amount):
        self.score_pop.text = f"+{amount}"

        self.score_pop.center_x = self.board.center_x
        self.score_pop.center_y = self.board.center_y

        self.score_pop.opacity = 1

        if self.animations_enabled:
            Animation.cancel_all(self.score_pop)

            anim = Animation(
                center_y=self.board.center_y + dp(65),
                opacity=0,
                duration=0.8
            )

            anim.start(self.score_pop)

        else:
            self.score_pop.opacity = 0

    # -------------------------------------------------
    # PIECES
    # -------------------------------------------------

    def create_piece(self, index):
        shape = random.choice(SHAPES)
        color = random.choice(COLORS)

        self.pieces[index] = (shape, color)

        self.piece_widgets[index].set_piece(
            shape,
            color
        )

    def new_game(self):
        self.score = 0
        self.rotations_left = 3

        self.game_over = False
        self.game_recorded = False

        self.drag_index = None
        self.selected_index = 0

        self.combo_streak = 0

        self.board.reset()
        self.preview.hide()
        self.line_fx.clear_fx()

        self.effects.particles = []
        self.effects.wave_progress = -1

        self.game_over_panel.opacity = 0
        self.game_over_panel.disabled = True

        self.message.text = (
            "DRAG A PIECE ONTO THE BOARD"
        )

        for i in range(3):
            self.create_piece(i)

        self.update_score()
        self.update_rotation_label()
        self.refresh_selection()

        self.save_stats()

    def refresh_selection(self):
        for piece in self.piece_widgets:
            piece.draw_piece()

    # -------------------------------------------------
    # ROTATION
    # -------------------------------------------------

    def update_rotation_label(self):
        self.rotation_label.text = (
            f"ROTATIONS  {self.rotations_left} / 3"
        )

        self.rotate_button.disabled = (
            self.rotations_left <= 0
            or self.game_over
            or self.drag_index is not None
        )

    def rotate_selected(self):
        if self.game_over:
            return

        if self.drag_index is not None:
            self.message.text = "DROP THE PIECE FIRST"
            return

        if self.rotations_left <= 0:
            self.message.text = "NO ROTATIONS LEFT"
            return

        index = self.selected_index

        if (
            index < 0
            or self.pieces[index] is None
        ):
            self.message.text = "SELECT A PIECE FIRST"
            return

        shape, color = self.pieces[index]

        new_shape = rotate_shape(shape)

        self.pieces[index] = (
            new_shape,
            color
        )

        self.piece_widgets[index].set_piece(
            new_shape,
            color
        )

        self.rotations_left -= 1

        self.message.text = "PIECE ROTATED"

        self.update_rotation_label()

    # -------------------------------------------------
    # DRAG
    # -------------------------------------------------

    def start_drag(self, index, touch):
        if self.game_over:
            return

        self.selected_index = index
        self.drag_index = index

        self.refresh_selection()

        shape, color = self.pieces[index]

        self.preview.show(
            self.board,
            shape,
            color,
            touch
        )

        self.update_rotation_label()

    def update_drag(self, touch):
        self.preview.update_position(touch)

    def finish_drag(self, index, touch):
        self.preview.update_position(touch)

        valid = self.preview.valid
        row = self.preview.row
        col = self.preview.col

        self.preview.hide()
        self.drag_index = None

        self.update_rotation_label()

        if self.game_over:
            return

        piece = self.pieces[index]

        if piece is None:
            return

        shape, color = piece

        if not valid:
            self.message.text = "INVALID POSITION"
            return

        if not self.board.place(
            shape,
            row,
            col,
            color
        ):
            self.message.text = "INVALID POSITION"
            return

        self.pieces[index] = None

        self.piece_widgets[index].set_piece(
            [],
            color
        )

        self.total_blocks += len(shape)

        # Detect nearly completed lines
        perfect_move = self.detect_perfect_move()

        full_rows, full_cols = (
            self.board.clear_lines()
        )

        rows = len(full_rows)
        cols = len(full_cols)
        cleared = rows + cols

        if cleared > 0:
            self.total_rows += rows
            self.total_cols += cols

            self.combo_streak += 1

            self.add_score(cleared * 30)

            if cleared >= 4:
                title = "MEGA CLEAR!"
                effect_color = PINK

            elif cleared == 3:
                title = "TRIPLE CLEAR!"
                effect_color = CYAN

            elif cleared == 2:
                title = "DOUBLE CLEAR!"
                effect_color = PURPLE

            elif cols > 0 and rows == 0:
                title = "COLUMN CLEAR!"
                effect_color = GREEN

            else:
                title = "ROW CLEAR!"
                effect_color = CYAN

            if self.combo_streak >= 2:
                title = (
                    f"COMBO x{self.combo_streak}!"
                )

                effect_color = PINK

            self.message.text = title

            if self.effects_enabled:
                self.play_clear_effect(
                    full_rows,
                    full_cols,
                    effect_color
                )

        else:
            self.combo_streak = 0

            if perfect_move and self.effects_enabled:
                self.message.text = "PERFECT MOVE!"
                self.background.trigger_pulse(1)
                self.effects.start_wave(CYAN)
            else:
                self.message.text = "NICE MOVE"

        self.save_stats()

        if all(p is None for p in self.pieces):
            for i in range(3):
                self.create_piece(i)

        self.check_game_over()

    # -------------------------------------------------
    # PERFECT MOVE
    # -------------------------------------------------

    def detect_perfect_move(self):
        for r in range(GRID):
            filled = sum(
                1 for c in range(GRID)
                if self.board.cells[r][c] is not None
            )

            if filled == GRID - 1:
                return True

        for c in range(GRID):
            filled = sum(
                1 for r in range(GRID)
                if self.board.cells[r][c] is not None
            )

            if filled == GRID - 1:
                return True

        return False

    # -------------------------------------------------
    # CLEAR EFFECTS
    # -------------------------------------------------

    def play_clear_effect(self, rows, cols, color):
        self.line_fx.play(
            self.board,
            rows,
            cols,
            color
        )

        if not self.effects_enabled:
            return

        self.background.trigger_pulse(
            min(1.0, 0.35 + (len(rows) + len(cols)) * 0.15)
        )

        self.effects.start_wave(color)

        cell = self.board.cell_size

        # Particle bursts around cleared lines
        for row in rows:
            y = (
                self.board.board_bottom +
                (row + 0.5) * cell
            )

            for col in range(0, GRID, 3):
                x = (
                    self.board.board_left +
                    (col + 0.5) * cell
                )

                self.effects.burst(
                    x,
                    y,
                    color,
                    5
                )

        for col in cols:
            x = (
                self.board.board_left +
                (col + 0.5) * cell
            )

            for row in range(0, GRID, 3):
                y = (
                    self.board.board_bottom +
                    (row + 0.5) * cell
                )

                self.effects.burst(
                    x,
                    y,
                    color,
                    5
                )

        if len(rows) + len(cols) >= 2:
            self.effects.burst(
                self.board.center_x,
                self.board.center_y,
                PINK,
                35
            )

    # -------------------------------------------------
    # GAME OVER
    # -------------------------------------------------

    def has_any_move(self):
        for piece in self.pieces:
            if piece is None:
                continue

            shape, color = piece

            for row in range(GRID):
                for col in range(GRID):
                    if self.board.can_place(
                        shape,
                        row,
                        col
                    ):
                        return True

        return False

    def check_game_over(self):
        if self.game_over:
            return

        if not self.has_any_move():
            self.game_over = True

            self.preview.hide()

            if not self.game_recorded:
                self.games_played += 1
                self.game_recorded = True

            self.final_score.text = (
                f"SCORE: {self.score}\n"
                f"BEST: {self.best}"
            )

            self.game_over_panel.disabled = False

            if self.animations_enabled:
                Animation(
                    opacity=1,
                    duration=0.25
                ).start(self.game_over_panel)

            else:
                self.game_over_panel.opacity = 1

            self.message.text = "NO MORE MOVES"

            self.update_rotation_label()
            self.save_stats()

    # -------------------------------------------------
    # RESTART
    # -------------------------------------------------

    def confirm_restart(self):
        content = BoxLayout(
            orientation="vertical",
            padding=dp(12),
            spacing=dp(10)
        )

        content.add_widget(
            make_label(
                "Restart this game?",
                17,
                WHITE
            )
        )

        buttons = BoxLayout(
            size_hint_y=None,
            height=dp(45),
            spacing=dp(8)
        )

        yes = make_button(
            "YES",
            PINK,
            dp(42)
        )

        no = make_button(
            "CANCEL",
            CYAN,
            dp(42)
        )

        buttons.add_widget(yes)
        buttons.add_widget(no)

        content.add_widget(buttons)

        popup = Popup(
            title="RESTART",
            content=content,
            size_hint=(0.85, 0.32),
            background_color=PANEL
        )

        yes.bind(
            on_release=lambda *_: (
                popup.dismiss(),
                self.new_game()
            )
        )

        no.bind(
            on_release=popup.dismiss
        )

        popup.open()


# =====================================================
# MENU SCREEN
# =====================================================

class MenuScreen(Screen):

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)

        self.app = app

        root = FloatLayout()

        self.background = SpaceBackground()
        root.add_widget(self.background)

        layout = BoxLayout(
            orientation="vertical",
            padding=dp(28),
            spacing=dp(13),
            size_hint=(1, 0.85),
            pos_hint={
                "center_x": 0.5,
                "center_y": 0.5
            }
        )

        root.add_widget(layout)

        layout.add_widget(Widget())

        layout.add_widget(
            make_label(
                "[b]NEON BLOCKS[/b]",
                34,
                CYAN
            )
        )

        layout.add_widget(
            make_label(
                "A NEW GENERATION OF BLOCK PUZZLE",
                11,
                PURPLE
            )
        )

        layout.add_widget(Widget())

        play = make_button(
            "PLAY",
            GREEN,
            dp(55)
        )

        settings = make_button(
            "SETTINGS",
            CYAN,
            dp(50)
        )

        stats = make_button(
            "STATISTICS",
            PURPLE,
            dp(50)
        )

        play.bind(
            on_release=lambda *_: app.start_game()
        )

        settings.bind(
            on_release=lambda *_: app.show_settings()
        )

        stats.bind(
            on_release=lambda *_: app.show_stats()
        )

        layout.add_widget(play)
        layout.add_widget(settings)
        layout.add_widget(stats)

        layout.add_widget(Widget())

        layout.add_widget(
            make_label(
                "DIGITAL ATMOSPHERE  •  VERSION 5",
                11,
                WHITE
            )
        )

        layout.add_widget(Widget())

        self.add_widget(root)


# =====================================================
# SETTINGS SCREEN
# =====================================================

class SettingsScreen(Screen):

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)

        self.app = app

        layout = BoxLayout(
            orientation="vertical",
            padding=dp(20),
            spacing=dp(12)
        )

        self.background = SpaceBackground()
        self.add_widget(self.background)

        layout.add_widget(
            make_label(
                "[b]SETTINGS[/b]",
                28,
                CYAN
            )
        )

        self.animation_button = make_button(
            self.animation_text(),
            PURPLE
        )

        self.animation_button.bind(
            on_release=lambda *_: self.toggle_animations()
        )

        self.effects_button = make_button(
            self.effects_text(),
            CYAN
        )

        self.effects_button.bind(
            on_release=lambda *_: self.toggle_effects()
        )

        reset = make_button(
            "RESET BEST SCORE",
            PINK
        )

        reset.bind(
            on_release=lambda *_: self.confirm_reset()
        )

        back = make_button(
            "BACK TO MENU",
            CYAN
        )

        back.bind(
            on_release=lambda *_: app.go_menu()
        )

        layout.add_widget(self.animation_button)
        layout.add_widget(self.effects_button)
        layout.add_widget(reset)
        layout.add_widget(back)

        layout.add_widget(Widget())

        layout.add_widget(
            make_label(
                "NEON BLOCKS v5",
                12,
                WHITE
            )
        )

        self.add_widget(layout)

    def animation_text(self):
        enabled = self.app.data.get(
            "animations", True
        )

        return (
            "ANIMATIONS: ON"
            if enabled else
            "ANIMATIONS: OFF"
        )

    def effects_text(self):
        enabled = self.app.data.get(
            "effects", True
        )

        return (
            "SPECIAL EFFECTS: ON"
            if enabled else
            "SPECIAL EFFECTS: OFF"
        )

    def on_pre_enter(self, *args):
        self.animation_button.text = (
            self.animation_text()
        )

        self.effects_button.text = (
            self.effects_text()
        )

    def toggle_animations(self):
        enabled = self.app.data.get(
            "animations", True
        )

        self.app.data["animations"] = not enabled

        save_data(self.app.data)

        self.animation_button.text = (
            self.animation_text()
        )

    def toggle_effects(self):
        enabled = self.app.data.get(
            "effects", True
        )

        self.app.data["effects"] = not enabled

        save_data(self.app.data)

        self.effects_button.text = (
            self.effects_text()
        )

    def confirm_reset(self):
        content = BoxLayout(
            orientation="vertical",
            padding=dp(10),
            spacing=dp(10)
        )

        content.add_widget(
            make_label(
                "Delete your best score?",
                16,
                WHITE
            )
        )

        buttons = BoxLayout(
            size_hint_y=None,
            height=dp(45),
            spacing=dp(8)
        )

        yes = make_button(
            "DELETE",
            PINK,
            dp(42)
        )

        no = make_button(
            "CANCEL",
            CYAN,
            dp(42)
        )

        buttons.add_widget(yes)
        buttons.add_widget(no)

        content.add_widget(buttons)

        popup = Popup(
            title="CONFIRM",
            content=content,
            size_hint=(0.85, 0.32)
        )

        def delete_record(*args):
            self.app.data["best"] = 0
            save_data(self.app.data)
            popup.dismiss()

        yes.bind(on_release=delete_record)
        no.bind(on_release=popup.dismiss)

        popup.open()


# =====================================================
# STATISTICS SCREEN
# =====================================================

class StatsScreen(Screen):

    def __init__(self, app, **kwargs):
        super().__init__(**kwargs)

        self.app = app

        self.background = SpaceBackground()
        self.add_widget(self.background)

        self.layout = BoxLayout(
            orientation="vertical",
            padding=dp(20),
            spacing=dp(14)
        )

        self.layout.add_widget(
            make_label(
                "[b]STATISTICS[/b]",
                28,
                CYAN
            )
        )

        self.info = make_label(
            "",
            17,
            WHITE
        )

        self.layout.add_widget(self.info)

        back = make_button(
            "BACK TO MENU",
            PURPLE
        )

        back.bind(
            on_release=lambda *_: app.go_menu()
        )

        self.layout.add_widget(Widget())
        self.layout.add_widget(back)

        self.add_widget(self.layout)

    def on_pre_enter(self, *args):
        data = self.app.data

        self.info.text = (
            f"BEST SCORE: {data.get('best', 0)}\n\n"
            f"GAMES PLAYED: {data.get('games', 0)}\n\n"
            f"ROWS CLEARED: {data.get('rows', 0)}\n\n"
            f"COLUMNS CLEARED: {data.get('cols', 0)}\n\n"
            f"BLOCKS PLACED: {data.get('blocks', 0)}"
        )


# =====================================================
# APP
# =====================================================

class NeonBlocksApp(App):

    def build(self):
        self.title = "NEON BLOCKS"

        self.data = load_data()

        self.manager = ScreenManager()

        self.menu = MenuScreen(
            self,
            name="menu"
        )

        self.settings = SettingsScreen(
            self,
            name="settings"
        )

        self.stats = StatsScreen(
            self,
            name="stats"
        )

        self.manager.add_widget(self.menu)
        self.manager.add_widget(self.settings)
        self.manager.add_widget(self.stats)

        return self.manager

    def start_game(self):
        if self.manager.has_screen("game"):
            self.manager.remove_widget(
                self.manager.get_screen("game")
            )

        game = GameScreen(
            self,
            name="game"
        )

        self.manager.add_widget(game)
        self.manager.current = "game"

    def show_settings(self):
        self.manager.current = "settings"

    def show_stats(self):
        self.manager.current = "stats"

    def go_menu(self):
        self.manager.current = "menu"


# =====================================================
# RUN
# =====================================================

if __name__ == "__main__":
    NeonBlocksApp().run()